import { Outlet, Link, useLocation } from 'react-router';
import { motion } from 'motion/react';

export default function PublicLayout() {
  const location = useLocation();

  const navLinks = [
    { to: '/', label: 'Home' },
    { to: '/candidate', label: 'Apply as Candidate' },
    { to: '/company', label: 'Post a Job' },
    { to: '/about', label: 'About' },
    { to: '/contact', label: 'Contact' },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="bg-card border-b border-border sticky top-0 z-50 shadow-sm"
      >
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-xl">E</span>
              </div>
              <span className="text-2xl font-semibold text-primary">Elmotalq</span>
            </Link>

            {/* Navigation */}
            <nav className="hidden md:flex items-center gap-8">
              {navLinks.map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  className={`transition-colors hover:text-primary ${
                    location.pathname === link.to
                      ? 'text-primary font-medium'
                      : 'text-muted-foreground'
                  }`}
                >
                  {link.label}
                </Link>
              ))}
            </nav>

            {/* Admin Login */}
            <Link
              to="/admin/login"
              className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
            >
              Admin Login
            </Link>
          </div>
        </div>
      </motion.header>

      {/* Main Content */}
      <main className="flex-1">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-card border-t border-border mt-20">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                  <span className="text-primary-foreground font-bold text-xl">E</span>
                </div>
                <span className="text-xl font-semibold text-primary">Elmotalq</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Connecting talent with opportunity
              </p>
            </div>

            <div>
              <h4 className="font-medium mb-3">For Candidates</h4>
              <div className="space-y-2">
                <Link to="/candidate" className="block text-sm text-muted-foreground hover:text-primary">
                  Submit Profile
                </Link>
              </div>
            </div>

            <div>
              <h4 className="font-medium mb-3">For Companies</h4>
              <div className="space-y-2">
                <Link to="/company" className="block text-sm text-muted-foreground hover:text-primary">
                  Post Requirements
                </Link>
              </div>
            </div>

            <div>
              <h4 className="font-medium mb-3">About</h4>
              <div className="space-y-2">
                <Link to="/about" className="block text-sm text-muted-foreground hover:text-primary">
                  About Us
                </Link>
                <Link to="/contact" className="block text-sm text-muted-foreground hover:text-primary">
                  Contact
                </Link>
              </div>
            </div>
          </div>

          <div className="mt-8 pt-8 border-t border-border text-center text-sm text-muted-foreground">
            © {new Date().getFullYear()} Elmotalq. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
