import { useState } from 'react';
import { Link } from 'react-router';
import { motion } from 'motion/react';
import {
  Search,
  Filter,
  Plus,
  Eye,
  Edit,
  Trash2,
  ChevronLeft,
  ChevronRight,
  Download,
} from 'lucide-react';

export default function CompaniesList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    country: '',
    industry: '',
    assignedStatus: '',
  });
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;

  // Mock data
  const companies = Array.from({ length: 30 }, (_, i) => ({
    id: i + 1,
    companyName: ['Tech Solutions Inc', 'Global Innovations', 'Digital Agency', 'Future Corp'][
      i % 4
    ],
    contactPhone: '+201122233344',
    email: `company${i + 1}@example.com`,
    country: 'Egypt',
    city: ['Cairo', 'Alexandria', 'Giza'][i % 3],
    requiredJobTitle: ['Senior Developer', 'Product Manager', 'UI Designer', 'Data Scientist'][
      i % 4
    ],
    companyIndustry: ['Technology', 'Healthcare', 'Finance', 'E-commerce'][i % 4],
    assignedEmployee: i % 3 === 0 ? 'John Smith' : null,
    createdAt: new Date(2024, 0, i + 1).toISOString(),
  }));

  const totalPages = Math.ceil(companies.length / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const paginatedCompanies = companies.slice(startIndex, startIndex + pageSize);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Companies</h2>
          <p className="text-muted-foreground">Manage company requests and assignments</p>
        </div>
        <Link
          to="/admin/companies/new"
          className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Add Company
        </Link>
      </div>

      {/* Search and Filters */}
      <div className="bg-card rounded-xl p-6 border border-border space-y-4">
        <div className="flex gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search companies by name, industry..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-input-background border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`px-4 py-3 rounded-lg border transition-colors flex items-center gap-2 ${
              showFilters
                ? 'bg-primary text-primary-foreground border-primary'
                : 'bg-card border-border hover:bg-secondary'
            }`}
          >
            <Filter className="w-4 h-4" />
            Filters
          </button>
          <button className="px-4 py-3 bg-card border border-border rounded-lg hover:bg-secondary transition-colors flex items-center gap-2">
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>

        {/* Filters Panel */}
        {showFilters && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-border"
          >
            <div>
              <label className="block text-sm mb-2">Country</label>
              <input
                type="text"
                value={filters.country}
                onChange={(e) => setFilters({ ...filters, country: e.target.value })}
                className="w-full px-3 py-2 bg-input-background border border-input rounded-lg text-sm"
                placeholder="Filter by country"
              />
            </div>

            <div>
              <label className="block text-sm mb-2">Industry</label>
              <select
                value={filters.industry}
                onChange={(e) => setFilters({ ...filters, industry: e.target.value })}
                className="w-full px-3 py-2 bg-input-background border border-input rounded-lg text-sm"
              >
                <option value="">All Industries</option>
                <option value="technology">Technology</option>
                <option value="healthcare">Healthcare</option>
                <option value="finance">Finance</option>
                <option value="ecommerce">E-commerce</option>
              </select>
            </div>

            <div>
              <label className="block text-sm mb-2">Assignment Status</label>
              <select
                value={filters.assignedStatus}
                onChange={(e) => setFilters({ ...filters, assignedStatus: e.target.value })}
                className="w-full px-3 py-2 bg-input-background border border-input rounded-lg text-sm"
              >
                <option value="">All</option>
                <option value="assigned">Assigned</option>
                <option value="unassigned">Unassigned</option>
              </select>
            </div>
          </motion.div>
        )}
      </div>

      {/* Table */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted/50 border-b border-border">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-medium">Company Name</th>
                <th className="px-6 py-4 text-left text-sm font-medium">Contact</th>
                <th className="px-6 py-4 text-left text-sm font-medium">Location</th>
                <th className="px-6 py-4 text-left text-sm font-medium">Required Job</th>
                <th className="px-6 py-4 text-left text-sm font-medium">Industry</th>
                <th className="px-6 py-4 text-left text-sm font-medium">Assigned To</th>
                <th className="px-6 py-4 text-left text-sm font-medium">Created</th>
                <th className="px-6 py-4 text-left text-sm font-medium">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {paginatedCompanies.map((company) => (
                <tr key={company.id} className="hover:bg-secondary/30 transition-colors">
                  <td className="px-6 py-4">
                    <div className="font-medium">{company.companyName}</div>
                    <div className="text-sm text-muted-foreground">{company.companyIndustry}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm">{company.email}</div>
                    <div className="text-sm text-muted-foreground">{company.contactPhone}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm">{company.city}</div>
                    <div className="text-sm text-muted-foreground">{company.country}</div>
                  </td>
                  <td className="px-6 py-4 text-sm">{company.requiredJobTitle}</td>
                  <td className="px-6 py-4 text-sm">{company.companyIndustry}</td>
                  <td className="px-6 py-4">
                    {company.assignedEmployee ? (
                      <span className="text-sm px-3 py-1 bg-primary/10 text-primary rounded-full">
                        {company.assignedEmployee}
                      </span>
                    ) : (
                      <span className="text-sm px-3 py-1 bg-muted text-muted-foreground rounded-full">
                        Unassigned
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-sm text-muted-foreground">
                    {new Date(company.createdAt).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <Link
                        to={`/admin/companies/${company.id}`}
                        className="p-2 hover:bg-secondary rounded-lg transition-colors"
                        title="View"
                      >
                        <Eye className="w-4 h-4 text-muted-foreground" />
                      </Link>
                      <Link
                        to={`/admin/companies/${company.id}/edit`}
                        className="p-2 hover:bg-secondary rounded-lg transition-colors"
                        title="Edit"
                      >
                        <Edit className="w-4 h-4 text-muted-foreground" />
                      </Link>
                      <button
                        className="p-2 hover:bg-destructive/10 rounded-lg transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="px-6 py-4 border-t border-border flex items-center justify-between">
          <div className="text-sm text-muted-foreground">
            Showing {startIndex + 1} to {Math.min(startIndex + pageSize, companies.length)} of{' '}
            {companies.length} companies
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-2 rounded-lg border border-border hover:bg-secondary disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-1">
              {Array.from({ length: Math.min(3, totalPages) }, (_, i) => {
                const page = i + 1;
                return (
                  <button
                    key={page}
                    onClick={() => setCurrentPage(page)}
                    className={`px-3 py-1 rounded-lg transition-colors ${
                      currentPage === page
                        ? 'bg-primary text-primary-foreground'
                        : 'hover:bg-secondary'
                    }`}
                  >
                    {page}
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-2 rounded-lg border border-border hover:bg-secondary disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
