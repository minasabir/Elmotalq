import { useState } from 'react';
import { Link, useParams, useNavigate } from 'react-router';
import { ArrowLeft, Save } from 'lucide-react';

export default function CompanyForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEdit = Boolean(id);

  const [formData, setFormData] = useState({
    companyName: isEdit ? 'Tech Solutions Inc' : '',
    contactPhone: isEdit ? '+201122233344' : '',
    email: isEdit ? 'hr@techsolutions.com' : '',
    country: isEdit ? 'Egypt' : '',
    city: isEdit ? 'Cairo' : '',
    requiredJobTitle: isEdit ? 'Senior Software Developer' : '',
    companyIndustry: isEdit ? 'Technology' : '',
  });

  const updateField = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/admin/companies');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Link
          to={isEdit ? `/admin/companies/${id}` : '/admin/companies'}
          className="p-2 hover:bg-secondary rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div>
          <h2 className="text-2xl font-bold">{isEdit ? 'Edit Company' : 'Add New Company'}</h2>
          <p className="text-muted-foreground">
            {isEdit ? 'Update company information' : 'Register a new company request'}
          </p>
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit}>
        <div className="bg-card rounded-xl p-8 border border-border space-y-8">
          {/* Company Information */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Company Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2">
                <label className="block mb-2">
                  Company Name <span className="text-destructive">*</span>
                </label>
                <input
                  type="text"
                  required
                  maxLength={200}
                  value={formData.companyName}
                  onChange={(e) => updateField('companyName', e.target.value)}
                  className="w-full px-4 py-3 bg-input-background border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="Enter company name"
                />
              </div>

              <div>
                <label className="block mb-2">
                  Company Industry <span className="text-destructive">*</span>
                </label>
                <input
                  type="text"
                  required
                  maxLength={200}
                  value={formData.companyIndustry}
                  onChange={(e) => updateField('companyIndustry', e.target.value)}
                  className="w-full px-4 py-3 bg-input-background border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="e.g., Technology, Healthcare"
                />
              </div>

              <div>
                <label className="block mb-2">
                  Required Job Title <span className="text-destructive">*</span>
                </label>
                <input
                  type="text"
                  required
                  maxLength={200}
                  value={formData.requiredJobTitle}
                  onChange={(e) => updateField('requiredJobTitle', e.target.value)}
                  className="w-full px-4 py-3 bg-input-background border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="e.g., Senior Developer"
                />
              </div>
            </div>
          </div>

          {/* Contact Information */}
          <div className="pt-6 border-t border-border">
            <h3 className="text-lg font-semibold mb-4">Contact Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block mb-2">
                  Contact Phone <span className="text-destructive">*</span>
                </label>
                <input
                  type="tel"
                  required
                  maxLength={20}
                  value={formData.contactPhone}
                  onChange={(e) => updateField('contactPhone', e.target.value)}
                  className="w-full px-4 py-3 bg-input-background border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="+20 123 456 7890"
                />
              </div>

              <div>
                <label className="block mb-2">
                  Email <span className="text-destructive">*</span>
                </label>
                <input
                  type="email"
                  required
                  maxLength={255}
                  value={formData.email}
                  onChange={(e) => updateField('email', e.target.value)}
                  className="w-full px-4 py-3 bg-input-background border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="hr@company.com"
                />
              </div>
            </div>
          </div>

          {/* Location */}
          <div className="pt-6 border-t border-border">
            <h3 className="text-lg font-semibold mb-4">Location</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block mb-2">
                  Country <span className="text-destructive">*</span>
                </label>
                <input
                  type="text"
                  required
                  maxLength={100}
                  value={formData.country}
                  onChange={(e) => updateField('country', e.target.value)}
                  className="w-full px-4 py-3 bg-input-background border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="Egypt"
                />
              </div>

              <div>
                <label className="block mb-2">
                  City <span className="text-destructive">*</span>
                </label>
                <input
                  type="text"
                  required
                  maxLength={100}
                  value={formData.city}
                  onChange={(e) => updateField('city', e.target.value)}
                  className="w-full px-4 py-3 bg-input-background border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="Cairo"
                />
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="pt-6 border-t border-border flex items-center gap-4">
            <button
              type="submit"
              className="px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              {isEdit ? 'Update Company' : 'Create Company'}
            </button>
            <Link
              to={isEdit ? `/admin/companies/${id}` : '/admin/companies'}
              className="px-6 py-3 bg-secondary text-secondary-foreground rounded-lg hover:bg-secondary/80 transition-colors"
            >
              Cancel
            </Link>
          </div>
        </div>
      </form>
    </div>
  );
}
