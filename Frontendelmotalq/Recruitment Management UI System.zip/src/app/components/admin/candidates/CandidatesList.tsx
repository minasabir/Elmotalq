import { useState } from 'react';
import { Link } from 'react-router';
import { motion } from 'motion/react';
import {
  Search,
  Filter,
  Plus,
  Eye,
  Edit,
  Trash2,
  ChevronLeft,
  ChevronRight,
  Download,
} from 'lucide-react';

export default function CandidatesList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    gender: '',
    education: '',
    experience: '',
    assignedStatus: '',
  });
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;

  // Mock data
  const candidates = Array.from({ length: 50 }, (_, i) => ({
    id: i + 1,
    fullName: ['Ahmed Mohamed', 'Sara Ibrahim', 'Mohamed Ali', 'Nour Hassan', 'Layla Ahmed'][
      i % 5
    ],
    phoneNumber: '+201234567890',
    jobTitle: ['Software Developer', 'UX Designer', 'Data Analyst', 'Marketing Manager'][i % 4],
    gender: i % 2 === 0 ? 'Male' : 'Female',
    education: ['Bachelor', 'Master', 'PhD', 'Diploma'][i % 4],
    yearsOfExperience: Math.floor(Math.random() * 10) + 1,
    country: 'Egypt',
    assignedEmployee: i % 3 === 0 ? 'John Smith' : null,
    createdAt: new Date(2024, 0, i + 1).toISOString(),
  }));

  const totalPages = Math.ceil(candidates.length / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const paginatedCandidates = candidates.slice(startIndex, startIndex + pageSize);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Candidates</h2>
          <p className="text-muted-foreground">Manage candidate profiles and assignments</p>
        </div>
        <Link
          to="/admin/candidates/new"
          className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Add Candidate
        </Link>
      </div>

      {/* Search and Filters */}
      <div className="bg-card rounded-xl p-6 border border-border space-y-4">
        <div className="flex gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search candidates by name, job title..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-input-background border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`px-4 py-3 rounded-lg border transition-colors flex items-center gap-2 ${
              showFilters
                ? 'bg-primary text-primary-foreground border-primary'
                : 'bg-card border-border hover:bg-secondary'
            }`}
          >
            <Filter className="w-4 h-4" />
            Filters
          </button>
          <button className="px-4 py-3 bg-card border border-border rounded-lg hover:bg-secondary transition-colors flex items-center gap-2">
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>

        {/* Filters Panel */}
        {showFilters && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-4 border-t border-border"
          >
            <div>
              <label className="block text-sm mb-2">Gender</label>
              <select
                value={filters.gender}
                onChange={(e) => setFilters({ ...filters, gender: e.target.value })}
                className="w-full px-3 py-2 bg-input-background border border-input rounded-lg text-sm"
              >
                <option value="">All</option>
                <option value="0">Male</option>
                <option value="1">Female</option>
              </select>
            </div>

            <div>
              <label className="block text-sm mb-2">Education</label>
              <select
                value={filters.education}
                onChange={(e) => setFilters({ ...filters, education: e.target.value })}
                className="w-full px-3 py-2 bg-input-background border border-input rounded-lg text-sm"
              >
                <option value="">All</option>
                <option value="0">High School</option>
                <option value="1">Diploma</option>
                <option value="2">Bachelor</option>
                <option value="3">Master</option>
                <option value="4">PhD</option>
              </select>
            </div>

            <div>
              <label className="block text-sm mb-2">Experience</label>
              <select
                value={filters.experience}
                onChange={(e) => setFilters({ ...filters, experience: e.target.value })}
                className="w-full px-3 py-2 bg-input-background border border-input rounded-lg text-sm"
              >
                <option value="">All</option>
                <option value="0-2">0-2 years</option>
                <option value="3-5">3-5 years</option>
                <option value="6+">6+ years</option>
              </select>
            </div>

            <div>
              <label className="block text-sm mb-2">Assignment Status</label>
              <select
                value={filters.assignedStatus}
                onChange={(e) => setFilters({ ...filters, assignedStatus: e.target.value })}
                className="w-full px-3 py-2 bg-input-background border border-input rounded-lg text-sm"
              >
                <option value="">All</option>
                <option value="assigned">Assigned</option>
                <option value="unassigned">Unassigned</option>
              </select>
            </div>
          </motion.div>
        )}
      </div>

      {/* Table */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted/50 border-b border-border">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-medium">Name</th>
                <th className="px-6 py-4 text-left text-sm font-medium">Job Title</th>
                <th className="px-6 py-4 text-left text-sm font-medium">Phone</th>
                <th className="px-6 py-4 text-left text-sm font-medium">Education</th>
                <th className="px-6 py-4 text-left text-sm font-medium">Experience</th>
                <th className="px-6 py-4 text-left text-sm font-medium">Assigned To</th>
                <th className="px-6 py-4 text-left text-sm font-medium">Created</th>
                <th className="px-6 py-4 text-left text-sm font-medium">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {paginatedCandidates.map((candidate) => (
                <tr key={candidate.id} className="hover:bg-secondary/30 transition-colors">
                  <td className="px-6 py-4">
                    <div className="font-medium">{candidate.fullName}</div>
                    <div className="text-sm text-muted-foreground">{candidate.gender}</div>
                  </td>
                  <td className="px-6 py-4">{candidate.jobTitle}</td>
                  <td className="px-6 py-4 text-sm text-muted-foreground">
                    {candidate.phoneNumber}
                  </td>
                  <td className="px-6 py-4 text-sm">{candidate.education}</td>
                  <td className="px-6 py-4 text-sm">{candidate.yearsOfExperience} years</td>
                  <td className="px-6 py-4">
                    {candidate.assignedEmployee ? (
                      <span className="text-sm px-3 py-1 bg-primary/10 text-primary rounded-full">
                        {candidate.assignedEmployee}
                      </span>
                    ) : (
                      <span className="text-sm px-3 py-1 bg-muted text-muted-foreground rounded-full">
                        Unassigned
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-sm text-muted-foreground">
                    {new Date(candidate.createdAt).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <Link
                        to={`/admin/candidates/${candidate.id}`}
                        className="p-2 hover:bg-secondary rounded-lg transition-colors"
                        title="View"
                      >
                        <Eye className="w-4 h-4 text-muted-foreground" />
                      </Link>
                      <Link
                        to={`/admin/candidates/${candidate.id}/edit`}
                        className="p-2 hover:bg-secondary rounded-lg transition-colors"
                        title="Edit"
                      >
                        <Edit className="w-4 h-4 text-muted-foreground" />
                      </Link>
                      <button
                        className="p-2 hover:bg-destructive/10 rounded-lg transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="px-6 py-4 border-t border-border flex items-center justify-between">
          <div className="text-sm text-muted-foreground">
            Showing {startIndex + 1} to {Math.min(startIndex + pageSize, candidates.length)} of{' '}
            {candidates.length} candidates
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-2 rounded-lg border border-border hover:bg-secondary disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-1">
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                const page = i + 1;
                return (
                  <button
                    key={page}
                    onClick={() => setCurrentPage(page)}
                    className={`px-3 py-1 rounded-lg transition-colors ${
                      currentPage === page
                        ? 'bg-primary text-primary-foreground'
                        : 'hover:bg-secondary'
                    }`}
                  >
                    {page}
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-2 rounded-lg border border-border hover:bg-secondary disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
