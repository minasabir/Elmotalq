import { useState } from 'react';
import { Link, useParams, useNavigate } from 'react-router';
import { ArrowLeft, Save } from 'lucide-react';

export default function CandidateForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEdit = Boolean(id);

  const [formData, setFormData] = useState({
    fullName: isEdit ? 'Ahmed Mohamed' : '',
    phoneNumber: isEdit ? '+201234567890' : '',
    jobTitle: isEdit ? 'Software Developer' : '',
    gender: isEdit ? '0' : '',
    educationalQualification: isEdit ? '2' : '',
    yearsOfExperience: isEdit ? '5' : '',
    graduationYear: isEdit ? '2020' : '',
    country: isEdit ? 'Egypt' : '',
    governorate: isEdit ? 'Cairo' : '',
  });

  const updateField = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/admin/candidates');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Link
          to={isEdit ? `/admin/candidates/${id}` : '/admin/candidates'}
          className="p-2 hover:bg-secondary rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div>
          <h2 className="text-2xl font-bold">{isEdit ? 'Edit Candidate' : 'Add New Candidate'}</h2>
          <p className="text-muted-foreground">
            {isEdit ? 'Update candidate information' : 'Create a new candidate profile'}
          </p>
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit}>
        <div className="bg-card rounded-xl p-8 border border-border space-y-8">
          {/* Basic Information */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Basic Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block mb-2">
                  Full Name <span className="text-destructive">*</span>
                </label>
                <input
                  type="text"
                  required
                  maxLength={200}
                  value={formData.fullName}
                  onChange={(e) => updateField('fullName', e.target.value)}
                  className="w-full px-4 py-3 bg-input-background border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="Enter full name"
                />
              </div>

              <div>
                <label className="block mb-2">
                  Phone Number <span className="text-destructive">*</span>
                </label>
                <input
                  type="tel"
                  required
                  maxLength={20}
                  value={formData.phoneNumber}
                  onChange={(e) => updateField('phoneNumber', e.target.value)}
                  className="w-full px-4 py-3 bg-input-background border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="+20 123 456 7890"
                />
              </div>

              <div>
                <label className="block mb-2">
                  Job Title <span className="text-destructive">*</span>
                </label>
                <input
                  type="text"
                  required
                  maxLength={200}
                  value={formData.jobTitle}
                  onChange={(e) => updateField('jobTitle', e.target.value)}
                  className="w-full px-4 py-3 bg-input-background border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="e.g., Software Developer"
                />
              </div>

              <div>
                <label className="block mb-2">
                  Gender <span className="text-destructive">*</span>
                </label>
                <select
                  required
                  value={formData.gender}
                  onChange={(e) => updateField('gender', e.target.value)}
                  className="w-full px-4 py-3 bg-input-background border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                >
                  <option value="">Select gender</option>
                  <option value="0">Male</option>
                  <option value="1">Female</option>
                </select>
              </div>
            </div>
          </div>

          {/* Education & Experience */}
          <div className="pt-6 border-t border-border">
            <h3 className="text-lg font-semibold mb-4">Education & Experience</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block mb-2">Educational Qualification</label>
                <select
                  value={formData.educationalQualification}
                  onChange={(e) => updateField('educationalQualification', e.target.value)}
                  className="w-full px-4 py-3 bg-input-background border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                >
                  <option value="">Select qualification</option>
                  <option value="0">High School</option>
                  <option value="1">Diploma</option>
                  <option value="2">Bachelor</option>
                  <option value="3">Master</option>
                  <option value="4">PhD</option>
                  <option value="5">Other</option>
                </select>
              </div>

              <div>
                <label className="block mb-2">Graduation Year</label>
                <input
                  type="number"
                  min="1950"
                  max="2030"
                  value={formData.graduationYear}
                  onChange={(e) => updateField('graduationYear', e.target.value)}
                  className="w-full px-4 py-3 bg-input-background border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="2020"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block mb-2">Years of Experience</label>
                <input
                  type="number"
                  min="0"
                  value={formData.yearsOfExperience}
                  onChange={(e) => updateField('yearsOfExperience', e.target.value)}
                  className="w-full px-4 py-3 bg-input-background border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="0"
                />
              </div>
            </div>
          </div>

          {/* Location */}
          <div className="pt-6 border-t border-border">
            <h3 className="text-lg font-semibold mb-4">Location</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block mb-2">Country</label>
                <input
                  type="text"
                  maxLength={100}
                  value={formData.country}
                  onChange={(e) => updateField('country', e.target.value)}
                  className="w-full px-4 py-3 bg-input-background border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="Egypt"
                />
              </div>

              <div>
                <label className="block mb-2">Governorate</label>
                <input
                  type="text"
                  maxLength={100}
                  value={formData.governorate}
                  onChange={(e) => updateField('governorate', e.target.value)}
                  className="w-full px-4 py-3 bg-input-background border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="Cairo"
                />
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="pt-6 border-t border-border flex items-center gap-4">
            <button
              type="submit"
              className="px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              {isEdit ? 'Update Candidate' : 'Create Candidate'}
            </button>
            <Link
              to={isEdit ? `/admin/candidates/${id}` : '/admin/candidates'}
              className="px-6 py-3 bg-secondary text-secondary-foreground rounded-lg hover:bg-secondary/80 transition-colors"
            >
              Cancel
            </Link>
          </div>
        </div>
      </form>
    </div>
  );
}
